from django.apps import AppConfig


class OrganizationsConfig(AppConfig):
    name = 'apps.organizations'
    verbose_name = "机构管理"
